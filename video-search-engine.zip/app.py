
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.staticfiles import StaticFiles
import os
import subprocess

from utils.video_processing import extract_frames
from utils.transcription import extract_audio, transcribe
from utils.embeddings import get_text_embeddings
from utils.vector_store import VectorStore

app = FastAPI()
app.mount("/", StaticFiles(directory="static", html=True), name="static")

vector_store = VectorStore(dim=384)

def download_youtube(url, output_path):
    subprocess.call(["yt-dlp", "-o", output_path, url])

@app.post("/upload/")
async def upload_video(file: UploadFile = File(None), url: str = Form(None)):
    if url:
        video_path = "data/videos/youtube_video.mp4"
        download_youtube(url, video_path)
    else:
        video_path = f"data/videos/{file.filename}"
        with open(video_path, "wb") as f:
            f.write(await file.read())

    extract_frames(video_path, "data/frames")
    extract_audio(video_path, "data/audio/audio.wav")

    segments = transcribe("data/audio/audio.wav")

    texts = [seg["text"] for seg in segments]
    timestamps = [seg["start"] for seg in segments]

    embeddings = get_text_embeddings(texts)

    metadata = [{"text": t, "time": ts} for t, ts in zip(texts, timestamps)]
    vector_store.add(embeddings, metadata)

    return {"message": "Processed successfully"}

@app.get("/search/")
def search(query: str):
    emb = get_text_embeddings([query])[0]
    results = vector_store.search(emb)
    return {"results": results}
