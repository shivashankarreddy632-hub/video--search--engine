
import whisper
import subprocess

model = whisper.load_model("base")

def extract_audio(video_path, audio_path):
    subprocess.call([
        "ffmpeg", "-i", video_path,
        "-q:a", "0", "-map", "a", audio_path
    ])

def transcribe(audio_path):
    result = model.transcribe(audio_path)
    return result["segments"]
