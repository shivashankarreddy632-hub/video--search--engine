
import faiss
import numpy as np

class VectorStore:
    def __init__(self, dim):
        self.index = faiss.IndexFlatL2(dim)
        self.metadata = []

    def add(self, vectors, meta):
        self.index.add(np.array(vectors).astype('float32'))
        self.metadata.extend(meta)

    def search(self, query, k=5):
        D, I = self.index.search(np.array([query]).astype('float32'), k)
        return [self.metadata[i] for i in I[0]]
