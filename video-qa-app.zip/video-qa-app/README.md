# 🎬 VideoIQ — AI Video Transcription & Q&A

Upload any video or audio file up to **1 GB**. The app extracts the audio with FFmpeg,
transcribes it using Claude AI, then lets you ask questions about the content with
streaming answers and full conversation history.

---

## ✨ Features

| Feature | Detail |
|---|---|
| File size | Up to **1 GB** via chunked upload |
| Formats | MP4, MOV, AVI, WEBM, MKV, MP3, WAV, M4A, AAC, FLAC, OGG |
| Transcription | Claude Opus — verbatim, speaker-labeled, punctuated |
| Large videos | Auto-splits audio into 10-min segments, transcribes each |
| Q&A | Streaming answers grounded strictly in the transcript |
| History | Full multi-turn conversation memory per session |
| Cleanup | Files auto-deleted after 2 hours |

---

## 🚀 Quick Start (Local)

### Prerequisites
- Python 3.10+
- **FFmpeg** installed (`brew install ffmpeg` / `apt install ffmpeg` / `choco install ffmpeg`)
- Anthropic API key

### 1. Clone & install
```bash
git clone <your-repo>
cd video-qa-app
pip install -r requirements.txt
```

### 2. Set your API key
```bash
# Linux / macOS
export ANTHROPIC_API_KEY="sk-ant-..."

# Windows PowerShell
$env:ANTHROPIC_API_KEY = "sk-ant-..."
```

### 3. Run
```bash
python app.py
# → http://localhost:5000
```

---

## 🐳 Docker (Recommended for Production)

FFmpeg is included in the Docker image automatically.

```bash
# Build & run
docker build -t videoiq .
docker run -p 5000:8080 -e ANTHROPIC_API_KEY=sk-ant-... videoiq

# Or with docker-compose
ANTHROPIC_API_KEY=sk-ant-... docker-compose up
```

---

## ☁️ Deploy to Railway (Easiest)

1. Push your code to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Set environment variable: `ANTHROPIC_API_KEY = sk-ant-...`
4. Railway auto-detects the `Dockerfile` and deploys ✓

> Railway gives you 500 MB RAM free. For 1 GB videos, upgrade to a paid plan.

---

## ☁️ Deploy to Render

1. New Web Service → Connect GitHub repo
2. Runtime: **Docker**
3. Environment: `ANTHROPIC_API_KEY = sk-ant-...`
4. Instance type: **Standard** (for large file processing)

---

## ☁️ Deploy to Fly.io

```bash
# Install flyctl, then:
fly launch          # follow prompts, choose Dockerfile
fly secrets set ANTHROPIC_API_KEY=sk-ant-...
fly deploy
```

Edit `fly.toml` to increase memory for large videos:
```toml
[vm]
  memory = "2gb"
  cpu_kind = "shared"
  cpus = 2
```

---

## ⚙️ Configuration

| Env Variable | Default | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | **required** | Your Anthropic API key |
| `PORT` | `5000` | HTTP port |

Internal constants (edit `app.py`):
| Constant | Default | Description |
|---|---|---|
| `MAX_CONTENT_LENGTH` | 1 GB | Maximum upload size |
| `CHUNK_SIZE` | 5 MB | Upload chunk size |
| `AUDIO_CHUNK_SECS` | 600 s (10 min) | Audio segment length for transcription |

---

## 🔒 Security Notes

- Sessions are in-memory only — restart clears all data
- Files are deleted after 2 hours automatically
- No database required
- For production, add authentication middleware (e.g. HTTP Basic Auth via nginx)

---

## 📁 Project Structure

```
video-qa-app/
├── app.py              ← Flask backend (upload, transcription, Q&A)
├── templates/
│   └── index.html      ← Full frontend (upload UI, transcript, chat)
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── Procfile            ← For Heroku/Railway
└── README.md
```

---

## 🛠️ How It Works

```
User uploads video (chunked, up to 1 GB)
        ↓
Flask saves chunks → assembles file
        ↓
FFmpeg extracts 16kHz mono WAV audio
        ↓
Audio split into 10-minute segments
        ↓
Each segment → Claude Opus transcription API
        ↓
Segments joined into full transcript
        ↓
User asks questions → Claude answers with
streaming SSE, grounded in transcript
```

---

## 📝 License

MIT
