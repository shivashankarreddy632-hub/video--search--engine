import os
import uuid
import json
import math
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from flask import Flask, request, jsonify, render_template, Response, stream_with_context
import anthropic

app = Flask(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
UPLOAD_DIR   = Path(tempfile.gettempdir()) / "video_qa_uploads"
AUDIO_DIR    = Path(tempfile.gettempdir()) / "video_qa_audio"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
AUDIO_DIR.mkdir(parents=True, exist_ok=True)

MAX_CONTENT_LENGTH = 1 * 1024 * 1024 * 1024   # 1 GB
CHUNK_SIZE         = 5 * 1024 * 1024           # 5 MB chunks for upload
AUDIO_CHUNK_SECS   = 600                        # 10-minute audio chunks for transcription
MAX_AUDIO_MB       = 24                         # Anthropic file API limit ~25 MB

app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))

# In-memory session store  {session_id: {transcript, chunks, status, qa_history}}
sessions: dict[str, dict] = {}
sessions_lock = threading.Lock()

# ── Helpers ───────────────────────────────────────────────────────────────────

def ffmpeg_extract_audio(video_path: Path, audio_path: Path) -> None:
    """Extract audio from video as 16-kHz mono WAV (optimal for transcription)."""
    cmd = [
        "ffmpeg", "-y",
        "-i", str(video_path),
        "-vn",                    # no video
        "-ar", "16000",           # 16 kHz sample rate
        "-ac", "1",               # mono
        "-c:a", "pcm_s16le",      # 16-bit PCM WAV
        str(audio_path)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg error: {result.stderr[:500]}")


def ffmpeg_audio_duration(audio_path: Path) -> float:
    """Return duration of audio file in seconds."""
    cmd = [
        "ffprobe", "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        str(audio_path)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    info = json.loads(result.stdout)
    return float(info["format"]["duration"])


def split_audio(audio_path: Path, chunk_dir: Path, chunk_secs: int) -> list[Path]:
    """Split audio into chunk_secs-second segments. Returns list of chunk paths."""
    chunk_dir.mkdir(parents=True, exist_ok=True)
    duration = ffmpeg_audio_duration(audio_path)
    n_chunks  = math.ceil(duration / chunk_secs)
    chunks    = []
    for i in range(n_chunks):
        start = i * chunk_secs
        out   = chunk_dir / f"chunk_{i:04d}.wav"
        cmd   = [
            "ffmpeg", "-y",
            "-i", str(audio_path),
            "-ss", str(start),
            "-t",  str(chunk_secs),
            "-c",  "copy",
            str(out)
        ]
        subprocess.run(cmd, capture_output=True, timeout=300, check=True)
        chunks.append(out)
    return chunks


def transcribe_chunk(chunk_path: Path) -> str:
    """Transcribe a single audio chunk using Claude."""
    with open(chunk_path, "rb") as f:
        audio_bytes = f.read()

    import base64
    b64 = base64.b64encode(audio_bytes).decode()

    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=4096,
        system=(
            "You are an expert verbatim transcription engine. "
            "Transcribe every spoken word faithfully. "
            "Use proper punctuation and paragraph breaks. "
            "Label multiple speakers as [Speaker 1], [Speaker 2], etc. "
            "Mark unclear audio as [inaudible]. "
            "Remove filler sounds (um, uh) unless meaning-changing. "
            "Output ONLY the transcript text — no commentary."
        ),
        messages=[{
            "role": "user",
            "content": [
                {
                    "type": "document",
                    "source": {
                        "type": "base64",
                        "media_type": "audio/wav",
                        "data": b64
                    }
                },
                {
                    "type": "text",
                    "text": "Transcribe all spoken audio from this segment with maximum accuracy."
                }
            ]
        }]
    )
    return response.content[0].text.strip()


def transcribe_full_audio(audio_path: Path, session_id: str) -> str:
    """Split audio into chunks and transcribe each, updating session status."""
    chunk_dir = AUDIO_DIR / session_id / "chunks"
    update_status(session_id, "splitting", "Splitting audio into segments…", 10)

    chunks = split_audio(audio_path, chunk_dir, AUDIO_CHUNK_SECS)
    n      = len(chunks)
    texts  = []

    for i, chunk in enumerate(chunks):
        pct = 15 + int((i / n) * 70)
        update_status(session_id, "transcribing",
                      f"Transcribing segment {i+1} of {n}…", pct)
        text = transcribe_chunk(chunk)
        texts.append(text)

    return "\n\n".join(texts)


def update_status(session_id: str, stage: str, message: str, pct: int):
    with sessions_lock:
        if session_id in sessions:
            sessions[session_id]["status"] = {
                "stage": stage, "message": message, "pct": pct
            }


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


# ---------- Chunked upload ---------------------------------------------------

@app.route("/upload/init", methods=["POST"])
def upload_init():
    """Client calls this first to get a session_id and upload URL."""
    data       = request.json
    filename   = data.get("filename", "upload.mp4")
    total_size = int(data.get("size", 0))

    if total_size > MAX_CONTENT_LENGTH:
        return jsonify(error="File exceeds 1 GB limit"), 413

    session_id = str(uuid.uuid4())
    ext        = Path(filename).suffix.lower() or ".mp4"
    video_path = UPLOAD_DIR / f"{session_id}{ext}"

    with sessions_lock:
        sessions[session_id] = {
            "video_path"  : str(video_path),
            "filename"    : filename,
            "total_size"  : total_size,
            "received"    : 0,
            "transcript"  : "",
            "qa_history"  : [],
            "status"      : {"stage": "init", "message": "Ready", "pct": 0},
        }

    return jsonify(session_id=session_id)


@app.route("/upload/chunk/<session_id>", methods=["POST"])
def upload_chunk(session_id: str):
    """Receive one chunk of the file."""
    with sessions_lock:
        session = sessions.get(session_id)
    if not session:
        return jsonify(error="Unknown session"), 404

    chunk      = request.data
    video_path = Path(session["video_path"])

    with open(video_path, "ab") as f:
        f.write(chunk)

    with sessions_lock:
        sessions[session_id]["received"] += len(chunk)
        received   = sessions[session_id]["received"]
        total_size = sessions[session_id]["total_size"]

    pct = min(9, int((received / max(total_size, 1)) * 9))
    update_status(session_id, "uploading",
                  f"Uploading… {received // (1024*1024)} MB / {total_size // (1024*1024)} MB", pct)

    return jsonify(received=received)


@app.route("/upload/finalize/<session_id>", methods=["POST"])
def upload_finalize(session_id: str):
    """All chunks received — kick off transcription in background."""
    with sessions_lock:
        session = sessions.get(session_id)
    if not session:
        return jsonify(error="Unknown session"), 404

    thread = threading.Thread(target=_process_session, args=(session_id,), daemon=True)
    thread.start()

    return jsonify(ok=True)


def _process_session(session_id: str):
    """Background: extract audio → transcribe → store transcript."""
    try:
        with sessions_lock:
            session    = sessions[session_id]
        video_path = Path(session["video_path"])
        audio_dir  = AUDIO_DIR / session_id
        audio_dir.mkdir(parents=True, exist_ok=True)
        audio_path = audio_dir / "audio.wav"

        update_status(session_id, "extracting", "Extracting audio from video…", 10)

        # If it's already audio (mp3/wav etc) skip ffmpeg video extraction
        suffix = video_path.suffix.lower()
        if suffix in {".mp3", ".wav", ".ogg", ".m4a", ".flac", ".aac"}:
            # Just re-encode to 16k mono WAV
            cmd = [
                "ffmpeg", "-y", "-i", str(video_path),
                "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le",
                str(audio_path)
            ]
            subprocess.run(cmd, capture_output=True, timeout=600, check=True)
        else:
            ffmpeg_extract_audio(video_path, audio_path)

        transcript = transcribe_full_audio(audio_path, session_id)

        with sessions_lock:
            sessions[session_id]["transcript"] = transcript
        update_status(session_id, "done", "Transcription complete!", 100)

    except Exception as exc:
        update_status(session_id, "error", str(exc), 0)


# ---------- Status polling --------------------------------------------------

@app.route("/status/<session_id>")
def get_status(session_id: str):
    with sessions_lock:
        session = sessions.get(session_id)
    if not session:
        return jsonify(error="Unknown session"), 404
    return jsonify(
        status     = session["status"],
        transcript = session["transcript"] if session["status"]["stage"] == "done" else ""
    )


# ---------- Q&A -------------------------------------------------------------

@app.route("/ask/<session_id>", methods=["POST"])
def ask(session_id: str):
    """Answer a question about the transcript. Streams the response."""
    with sessions_lock:
        session = sessions.get(session_id)
    if not session:
        return jsonify(error="Unknown session"), 404

    transcript = session.get("transcript", "")
    if not transcript:
        return jsonify(error="No transcript available yet"), 400

    data     = request.json
    question = data.get("question", "").strip()
    if not question:
        return jsonify(error="Empty question"), 400

    # Append user message to history
    with sessions_lock:
        sessions[session_id]["qa_history"].append(
            {"role": "user", "content": question}
        )
        history = list(sessions[session_id]["qa_history"])

    system_prompt = f"""You are an expert video content analyst with access to the complete transcript of a video.
Answer every question based strictly on the transcript provided. Be accurate, detailed, and quote relevant parts.
If the answer is not in the transcript, say so clearly.

FULL TRANSCRIPT:
\"\"\"
{transcript}
\"\"\"

Guidelines:
- Quote specific transcript passages when useful (use quotation marks).
- Use bullet points or numbered lists for multi-part answers.
- If asked to summarize, cover all major topics systematically.
- Be concise but thorough. Accuracy is your highest priority."""

    def generate():
        full_answer = ""
        try:
            with client.messages.stream(
                model="claude-opus-4-5",
                max_tokens=2048,
                system=system_prompt,
                messages=history,
            ) as stream:
                for text in stream.text_stream:
                    full_answer += text
                    yield f"data: {json.dumps({'text': text})}\n\n"

            # Save assistant reply
            with sessions_lock:
                sessions[session_id]["qa_history"].append(
                    {"role": "assistant", "content": full_answer}
                )
            yield f"data: {json.dumps({'done': True})}\n\n"

        except Exception as exc:
            yield f"data: {json.dumps({'error': str(exc)})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control"  : "no-cache",
            "X-Accel-Buffering": "no",
        }
    )


@app.route("/transcript/<session_id>")
def get_transcript(session_id: str):
    with sessions_lock:
        session = sessions.get(session_id)
    if not session:
        return jsonify(error="Unknown session"), 404
    return jsonify(transcript=session.get("transcript", ""))


@app.route("/clear_history/<session_id>", methods=["POST"])
def clear_history(session_id: str):
    with sessions_lock:
        if session_id in sessions:
            sessions[session_id]["qa_history"] = []
    return jsonify(ok=True)


# ── Cleanup thread ────────────────────────────────────────────────────────────

def _cleanup_loop():
    """Delete files older than 2 hours to free disk space."""
    while True:
        time.sleep(3600)
        cutoff = time.time() - 7200
        for p in list(UPLOAD_DIR.iterdir()) + list(AUDIO_DIR.iterdir()):
            try:
                if p.stat().st_mtime < cutoff:
                    if p.is_file():
                        p.unlink()
                    elif p.is_dir():
                        import shutil
                        shutil.rmtree(p, ignore_errors=True)
            except Exception:
                pass

threading.Thread(target=_cleanup_loop, daemon=True).start()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
